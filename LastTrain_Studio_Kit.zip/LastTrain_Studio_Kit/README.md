# 《末班車》Roblox Studio 開發套件

這是可以匯入 Roblox Studio 的可玩灰盒原型。包含第一人稱 HUD、三階段任務、程式生成的地鐵站、站務員追逐 AI、車票幣、角色外觀解鎖、Game Pass 與 Developer Product 購買流程。

## 專案檔案

`src` 內的 Luau 檔按 Roblox 服務分好。建議使用 Rojo 將資料夾同步到 Studio；如果你不使用 Rojo，可以在 Studio Explorer 建立下列服務/資料夾，再將同名程式碼複製到對應的 Script、LocalScript 或 ModuleScript：

- `ReplicatedStorage/LastTrain/Shared/GameConfig.lua`：ModuleScript
- `ServerScriptService/LastTrain/Bootstrap.server.lua`：Script
- `ServerScriptService/LastTrain/ProfileService.lua`：ModuleScript
- `ServerScriptService/LastTrain/CharacterShopServer.server.lua`：Script
- `ServerScriptService/LastTrain/ProfileLoader.server.lua`、`Atmosphere.server.lua`、`WorldBuilder.server.lua`、`RoundController.server.lua`、`StationmasterAI.server.lua`：Scripts
- `StarterPlayer/StarterPlayerScripts/LastTrainClient.client.lua`：LocalScript

`default.project.json` 是 Rojo 專案設定。若已安裝 Rojo，從此資料夾執行 `rojo serve`，再用 Studio 的 Rojo 外掛連線。未使用 Rojo 時，依上方清單逐一貼入程式碼即可。

## 首次設定

1. 在 Roblox Studio 建立新 Experience，將本專案的腳本放入上述服務位置。
2. 在 `StarterPlayer` 將 `CameraMode` 設為 `LockFirstPerson`；用戶端腳本也會在進入時鎖定第一人稱。
3. 發布 Experience。在 Creator Dashboard 啟用 Data Stores；Studio 測試資料存取需要在 Game Settings > Security 開啟 Studio Access to API Services。開發時建議先用測試副本，避免碰到正式資料。
4. 首次開始遊戲時，`WorldBuilder` 會在 Workspace 建立可玩的站體灰盒；場景需在 Play 模式中生成。後續可用自製 MeshPart、SurfaceAppearance、貼花、音效和動畫替換灰盒。
5. 可在 Studio 渲染設定提高 Editor Quality Level。高畫質仍取決於玩家裝置；控制光源數量並在低階手機上檢查效能。

## Robux 商品設定

1. 在 Creator Dashboard > Monetization 建立 Developer Products，例如「300 張車票幣」與「1,000 張車票幣」，把各自的 Product ID 填進 `GameConfig.Products` 的 `ProductId`。
2. 建立一個永久 Game Pass，設定「深夜站務員」角色的價格，將 Pass ID 填入 `GameConfig.Skins.NightGuard.GamePassId`。
3. 目前為 0 的 ID 代表購買按鈕尚未啟用。不要把價格數字當成 ID。
4. Developer Product 只由伺服器的 `ProcessReceipt` 發幣；收據 ID 會與個人資料一同儲存，重送收據不會重複發獎。Game Pass 會由伺服器查驗持有狀態並授予角色。

角色目前以不同身體配色呈現，可選填服裝模板 ID 讓角色穿上自有或有權使用的 Shirt/Pants。這個原型不含付費 UGC、角色套裝資產或動畫；可在後續美術階段加入。

## 玩法流程

- 查看公告：取得第一筆車票幣，站務員開始追逐。
- 啟動備用電源：深入月台並取得第二筆獎勵。
- 打開緊急車門：完成逃生，24 秒後新一輪開始。

多人共用同一輪任務進度；完成互動的玩家取得該階段獎勵。伺服器會檢查 ProximityPrompt 距離、角色購買金額、解鎖狀態與商品 ID。

## 高畫質美術落地順序

原型用 Future 光照、冷青色螢光燈、低飽和混凝土、局部紅色警示燈與遠端霧化建立氛圍；目前地圖幾何是可玩灰盒。正式美術可依序替換：

1. 把牆面、柱子、月台和車廂拆成可重複使用的模組 MeshPart，加入自製或授權的 Color、Normal、Roughness 貼圖與污漬貼花。
2. 為燈管建立亮暗故障變化，讓 PointLight 只放在主要燈具和警示燈；這樣能保留陰影，同時控制手機效能。
3. 補上列車內部、玻璃反射、站名牌、電纜、維修工具、粒子灰塵和環境音；重要互動物件用色彩或標示讓玩家在暗處仍能辨認。
4. 在高、中、低畫質和手機裝置上檢查可見度與影格率，再調整霧、陰影、Bloom 和光源距離。

請使用自己製作或有權使用的音效與素材。

## 注意

- 程式內的商品 ID 都是空值，必須自行建立商品並填入 ID 才能開放 Robux 購買。
- DataStore 的正式資料會跨伺服器保存。不要在已上線的正式體驗上用測試貨幣流程。
- Roblox Marketplace 購買提示由用戶端開啟；伺服器只回傳白名單中設定的商品 ID，並在伺服器端核發權益。
