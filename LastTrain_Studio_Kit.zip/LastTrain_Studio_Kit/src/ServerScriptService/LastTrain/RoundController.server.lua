local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local GameConfig = require(ReplicatedStorage:WaitForChild("LastTrain"):WaitForChild("Shared"):WaitForChild("GameConfig"))
local Profiles = require(script.Parent:WaitForChild("ProfileService"))
local objectiveEvent = ReplicatedStorage:WaitForChild("LastTrain"):WaitForChild("Remotes"):WaitForChild("ObjectiveUpdate")
local world = Workspace:WaitForChild("LastTrainWorld")
local objectiveFolder = world:WaitForChild("Objectives")
local stage = 0
local completed = false

local function broadcast()
    objectiveEvent:FireAllClients(stage, GameConfig.Objectives[stage + 1], completed)
end

local function resetRound()
    stage = 0
    completed = false
    Workspace:SetAttribute("LastTrainRoundStage", stage)
    broadcast()
end

for _, anchor in ipairs(objectiveFolder:GetChildren()) do
    local prompt = anchor:FindFirstChildOfClass("ProximityPrompt")
    if prompt then
        prompt.Triggered:Connect(function(player)
            if completed or anchor:GetAttribute("ObjectiveStage") ~= stage then return end
            local character = player.Character
            local root = character and character:FindFirstChild("HumanoidRootPart")
            local humanoid = character and character:FindFirstChildWhichIsA("Humanoid")
            if not root or not humanoid or humanoid.Health <= 0 then return end
            -- ProximityPrompt events are checked again on the server; remote clients cannot skip the map.
            if (root.Position - anchor.Position).Magnitude > prompt.MaxActivationDistance + 4 then return end

            stage += 1
            Workspace:SetAttribute("LastTrainRoundStage", stage)
            Profiles.AwardCoins(player, GameConfig.ObjectiveRewards[stage] or 0)
            if stage >= #GameConfig.Objectives then
                completed = true
            end
            broadcast()

            if completed then
                task.delay(24, resetRound)
            end
        end)
    end
end

Players.PlayerAdded:Connect(function(player)
    task.delay(2, function()
        if player.Parent then
            objectiveEvent:FireClient(player, stage, GameConfig.Objectives[stage + 1], completed)
        end
    end)
end)

broadcast()
