local Lighting = game:GetService("Lighting")

Lighting.Technology = Enum.Technology.Future
Lighting.ClockTime = 1.25
Lighting.Brightness = 1.35
Lighting.ExposureCompensation = -0.18
Lighting.GlobalShadows = true
Lighting.Ambient = Color3.fromRGB(30, 39, 49)
Lighting.OutdoorAmbient = Color3.fromRGB(17, 23, 31)
Lighting.EnvironmentDiffuseScale = 0.28
Lighting.EnvironmentSpecularScale = 0.32
Lighting.FogColor = Color3.fromRGB(22, 31, 43)
Lighting.FogStart = 90
Lighting.FogEnd = 260

local atmosphere = Lighting:FindFirstChildOfClass("Atmosphere") or Instance.new("Atmosphere")
atmosphere.Color = Color3.fromRGB(133, 156, 179)
atmosphere.Decay = Color3.fromRGB(39, 53, 70)
atmosphere.Density = 0.24
atmosphere.Glare = 0.08
atmosphere.Haze = 1.35
atmosphere.Offset = 0.1
atmosphere.Parent = Lighting

local color = Lighting:FindFirstChild("LastTrainColor") or Instance.new("ColorCorrectionEffect")
color.Name = "LastTrainColor"
color.Brightness = -0.035
color.Contrast = 0.16
color.Saturation = -0.22
color.TintColor = Color3.fromRGB(198, 216, 235)
color.Parent = Lighting

local bloom = Lighting:FindFirstChild("LastTrainBloom") or Instance.new("BloomEffect")
bloom.Name = "LastTrainBloom"
bloom.Intensity = 0.22
bloom.Size = 18
bloom.Threshold = 1.15
bloom.Parent = Lighting
