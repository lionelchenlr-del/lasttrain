-- Playable graybox station. Replace this modular blockout with custom meshes and PBR materials as the art pass.
local Workspace = game:GetService("Workspace")
local Lighting = game:GetService("Lighting")

local old = Workspace:FindFirstChild("LastTrainWorld")
if old then old:Destroy() end
local world = Instance.new("Folder")
world.Name = "LastTrainWorld"
world.Parent = Workspace
Workspace:SetAttribute("LastTrainRoundStage", 0)

local geometry = Instance.new("Folder")
geometry.Name = "Geometry"
geometry.Parent = world
local props = Instance.new("Folder")
props.Name = "Props"
props.Parent = world
local objectives = Instance.new("Folder")
objectives.Name = "Objectives"
objectives.Parent = world

local C = {
    Concrete = Color3.fromRGB(49, 59, 68),
    Tile = Color3.fromRGB(82, 94, 101),
    Dark = Color3.fromRGB(20, 27, 34),
    Metal = Color3.fromRGB(93, 105, 111),
    Yellow = Color3.fromRGB(222, 175, 67),
    Cyan = Color3.fromRGB(96, 191, 205),
    Red = Color3.fromRGB(174, 45, 38),
    Glass = Color3.fromRGB(27, 48, 59),
}

local function part(parent, name, size, position, color, material, transparency, canCollide)
    local p = Instance.new("Part")
    p.Name = name
    p.Size = size
    p.Position = position
    p.Color = color
    p.Material = material or Enum.Material.Concrete
    p.Transparency = transparency or 0
    p.Anchored = true
    p.CanCollide = canCollide ~= false
    p.TopSurface = Enum.SurfaceType.Smooth
    p.BottomSurface = Enum.SurfaceType.Smooth
    p.Parent = parent
    return p
end

local function light(host, color, brightness, range, shadows)
    local point = Instance.new("PointLight")
    point.Color = color
    point.Brightness = brightness
    point.Range = range
    point.Shadows = shadows == true
    point.Parent = host
    return point
end

-- Long tiled station, recessed track bed, raised platforms, and a sealed train shell.
part(geometry, "Foundation", Vector3.new(250, 2, 66), Vector3.new(0, -2, 0), C.Concrete, Enum.Material.Concrete)
part(geometry, "TrackBed", Vector3.new(244, 1, 22), Vector3.new(0, -1.1, 0), C.Dark, Enum.Material.Asphalt)
part(geometry, "Platform_Left", Vector3.new(238, 1, 21), Vector3.new(0, -0.5, -22.5), C.Concrete, Enum.Material.Concrete)
part(geometry, "Platform_Right", Vector3.new(238, 1, 21), Vector3.new(0, -0.5, 22.5), C.Concrete, Enum.Material.Concrete)
part(geometry, "PlatformEdge_Left", Vector3.new(236, 0.12, 1.1), Vector3.new(0, 0.08, -12.3), C.Yellow, Enum.Material.Neon)
part(geometry, "PlatformEdge_Right", Vector3.new(236, 0.12, 1.1), Vector3.new(0, 0.08, 12.3), C.Yellow, Enum.Material.Neon)
part(geometry, "BackWall_Left", Vector3.new(250, 18, 2), Vector3.new(0, 8, -33), C.Tile, Enum.Material.Concrete)
part(geometry, "BackWall_Right", Vector3.new(250, 18, 2), Vector3.new(0, 8, 33), C.Tile, Enum.Material.Concrete)
part(geometry, "Ceiling", Vector3.new(250, 2, 66), Vector3.new(0, 18, 0), C.Dark, Enum.Material.Metal)

-- Wall rails, tile bands, cable conduits, and structural columns add depth to the repeated space.
for _, side in ipairs({-1, 1}) do
    part(geometry, "WallLowerBand", Vector3.new(246, 2.4, 0.24), Vector3.new(0, 2.15, side * 31.85), C.Dark, Enum.Material.Metal)
    part(geometry, "WallSignBand", Vector3.new(246, 0.4, 0.3), Vector3.new(0, 11.1, side * 31.8), C.Cyan, Enum.Material.Neon, 0.18, false)
    for x = -108, 108, 18 do
        part(geometry, "Column", Vector3.new(1.7, 15, 1.7), Vector3.new(x, 7, side * 12.8), C.Metal, Enum.Material.Metal)
        part(geometry, "ColumnFoot", Vector3.new(2.4, 0.55, 2.4), Vector3.new(x, 0.25, side * 12.8), C.Dark, Enum.Material.Metal)
    end
    for x = -110, 110, 28 do
        local strip = part(geometry, "FluorescentFixture", Vector3.new(15, 0.24, 1.2), Vector3.new(x, 16.7, side * 22), Color3.fromRGB(194, 224, 228), Enum.Material.Neon, 0.05, false)
        light(strip, Color3.fromRGB(157, 208, 220), 1.65, 33, false)
    end
end

-- Rail lines and sleepers are below platform height, giving a readable track trench.
for _, z in ipairs({-4.6, 4.6}) do
    part(geometry, "Rail", Vector3.new(244, 0.3, 0.28), Vector3.new(0, -0.35, z), C.Metal, Enum.Material.Metal)
end
for x = -118, 118, 5 do
    part(geometry, "Sleeper", Vector3.new(0.8, 0.25, 13), Vector3.new(x, -0.55, 0), C.Dark, Enum.Material.WoodPlanks)
end

-- Train shell; later replace with a detailed carriage model and animated doors.
local train = Instance.new("Model")
train.Name = "LastTrainCar"
train.Parent = props
part(train, "CarBody", Vector3.new(60, 9.5, 11.3), Vector3.new(35, 4.3, 0), Color3.fromRGB(48, 58, 66), Enum.Material.Metal)
part(train, "Roof", Vector3.new(58, 0.55, 10.8), Vector3.new(35, 9.35, 0), C.Dark, Enum.Material.Metal)
part(train, "FrontStripe", Vector3.new(57, 0.75, 0.16), Vector3.new(35, 7.2, -5.72), C.Cyan, Enum.Material.Neon, 0.05, false)
for _, side in ipairs({-1, 1}) do
    for x = 10, 60, 10 do
        local window = part(train, "DarkWindow", Vector3.new(6.2, 3.3, 0.12), Vector3.new(x, 5.4, side * 5.72), C.Glass, Enum.Material.Glass, 0.12, false)
        window.Reflectance = 0.12
        part(train, "DoorSeam", Vector3.new(0.12, 6.3, 0.15), Vector3.new(x + 3.2, 4.4, side * 5.78), C.Metal, Enum.Material.Metal, 0, false)
    end
end
for _, x in ipairs({8, 62}) do
    local headlight = part(train, "TrainHeadlight", Vector3.new(1.4, 1.1, 0.18), Vector3.new(x, 2.4, -5.82), C.Cyan, Enum.Material.Neon, 0, false)
    light(headlight, C.Cyan, 1.1, 12, false)
end

-- Benches, information board, service cabinet, and warning lights.
for _, x in ipairs({-94, -43, 11, 98}) do
    for _, side in ipairs({-1, 1}) do
        local z = side * 26
        part(props, "BenchSeat", Vector3.new(8, 0.5, 2), Vector3.new(x, 1.1, z), C.Dark, Enum.Material.Metal)
        part(props, "BenchBack", Vector3.new(8, 2, 0.35), Vector3.new(x, 2.1, z + side * 0.85), C.Metal, Enum.Material.Metal)
        for dx = -3, 3, 6 do
            part(props, "BenchLeg", Vector3.new(0.35, 1.1, 1.4), Vector3.new(x + dx, 0.35, z), C.Metal, Enum.Material.Metal)
        end
    end
end

local notice = part(props, "ServiceNoticeBoard", Vector3.new(7, 4, 0.5), Vector3.new(-82, 4, -31.5), C.Dark, Enum.Material.Metal)
part(props, "NoticeHeader", Vector3.new(6.4, 0.45, 0.12), Vector3.new(-82, 5.45, -31.18), C.Cyan, Enum.Material.Neon, 0.08, false)
local noticeLight = part(props, "NoticeLamp", Vector3.new(1.1, 0.25, 0.4), Vector3.new(-82, 6.35, -31.3), C.Yellow, Enum.Material.Neon, 0, false)
light(noticeLight, C.Yellow, 0.65, 8, false)

local breaker = part(props, "AuxiliaryBreaker", Vector3.new(3.4, 4.4, 1.2), Vector3.new(-4, 2.5, -31.1), C.Dark, Enum.Material.Metal)
part(props, "BreakerScreen", Vector3.new(1.5, 0.8, 0.08), Vector3.new(-4, 3.45, -30.43), C.Cyan, Enum.Material.Neon, 0.08, false)
for i = 1, 3 do
    local bulb = part(props, "BreakerLamp", Vector3.new(0.28, 0.28, 0.08), Vector3.new(-4.85 + i * 0.45, 2.35, -30.4), i == 2 and C.Red or C.Yellow, Enum.Material.Neon, 0, false)
    light(bulb, bulb.Color, 0.18, 3, false)
end

local emergencyDoor = part(props, "EmergencyDoor", Vector3.new(5, 8, 0.6), Vector3.new(83, 4, -31.7), C.Red, Enum.Material.Metal)
part(props, "DoorWindow", Vector3.new(1.2, 2.2, 0.12), Vector3.new(83, 5.2, -31.32), C.Glass, Enum.Material.Glass, 0.08, false)
local exitLamp = part(props, "ExitLamp", Vector3.new(2.3, 0.55, 0.3), Vector3.new(83, 8.4, -31.35), C.Cyan, Enum.Material.Neon, 0, false)
light(exitLamp, C.Cyan, 0.5, 8, false)

-- Small colored lamps punctuate the otherwise cold station.
for _, x in ipairs({-112, -57, 55, 112}) do
    local lamp = part(geometry, "EmergencyWallLamp", Vector3.new(0.35, 1.2, 0.35), Vector3.new(x, 13.2, -31.5), C.Red, Enum.Material.Neon, 0, false)
    light(lamp, C.Red, 0.36, 10, false)
end

-- Spawn and objective anchors are server-validated by RoundController.
local spawn = Instance.new("SpawnLocation")
spawn.Name = "PlatformSpawn"
spawn.Size = Vector3.new(6, 1, 6)
spawn.Position = Vector3.new(-108, 0.4, -22)
spawn.Transparency = 1
spawn.CanCollide = false
spawn.Neutral = true
spawn.Duration = 0
spawn.Parent = world

local monsterSpawn = part(world, "MonsterSpawn", Vector3.new(2, 1, 2), Vector3.new(111, 0.15, 0), C.Red, Enum.Material.Neon, 1, false)
monsterSpawn.CanTouch = false

local objectiveSpecs = {
    { Name = "ReadNotice", Stage = 0, Position = Vector3.new(-82, 2.2, -27.5), Action = "查看公告" },
    { Name = "RestorePower", Stage = 1, Position = Vector3.new(-4, 2, -27.5), Action = "啟動電源" },
    { Name = "OpenTrainDoor", Stage = 2, Position = Vector3.new(79, 2, -22), Action = "開啟車門" },
}
for _, spec in ipairs(objectiveSpecs) do
    local anchor = part(objectives, spec.Name, Vector3.new(2.5, 3, 2.5), spec.Position, C.Cyan, Enum.Material.Neon, 1, false)
    anchor:SetAttribute("ObjectiveStage", spec.Stage)
    local prompt = Instance.new("ProximityPrompt")
    prompt.ActionText = spec.Action
    prompt.ObjectText = "末班車任務"
    prompt.HoldDuration = 0.8
    prompt.MaxActivationDistance = 10
    prompt.RequiresLineOfSight = false
    prompt.Parent = anchor
end

-- A subtle ambient hum source slot; add your own permitted audio asset ID in Studio.
local ambience = Instance.new("Sound")
ambience.Name = "StationAmbience"
ambience.SoundId = "" -- Optional: add an audio asset you own or have permission to use.
ambience.Looped = true
ambience.Volume = 0.18
ambience.RollOffMaxDistance = 180
ambience.Parent = world
