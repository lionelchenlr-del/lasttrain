-- Shared configuration. Replace every 0 marketplace ID with the ID from Creator Dashboard.
local GameConfig = {}

GameConfig.DataStoreName = "LastTrain_PlayerData_v1"
GameConfig.ObjectiveRewards = { 100, 150, 250 }
GameConfig.Objectives = {
    "查看月台公告，確認末班車狀況",
    "啟動備用電源，恢復控制室供電",
    "打開緊急車門，搭上末班車",
}

-- Purchasable characters are visual loadouts. The default body colors work without any assets.
-- Optional ShirtTemplate/PantsTemplate values accept clothing template asset IDs (not catalog page IDs).
GameConfig.Skins = {
    PlatformWorker = {
        DisplayName = "月台巡守",
        PriceCoins = 0,
        GamePassId = 0,
        Colors = { Main = Color3.fromRGB(80, 104, 112), Accent = Color3.fromRGB(216, 171, 78) },
        ShirtTemplate = 0,
        PantsTemplate = 0,
    },
    Conductor = {
        DisplayName = "夜班列車長",
        PriceCoins = 350,
        GamePassId = 0,
        Colors = { Main = Color3.fromRGB(38, 53, 72), Accent = Color3.fromRGB(220, 187, 111) },
        ShirtTemplate = 0,
        PantsTemplate = 0,
    },
    Signalman = {
        DisplayName = "號誌技師",
        PriceCoins = 700,
        GamePassId = 0,
        Colors = { Main = Color3.fromRGB(112, 49, 42), Accent = Color3.fromRGB(225, 207, 166) },
        ShirtTemplate = 0,
        PantsTemplate = 0,
    },
    NightGuard = {
        DisplayName = "深夜站務員",
        PriceCoins = 0,
        GamePassId = 0, -- Create a one-time game pass, then paste its ID here.
        RequiresGamePass = true,
        Colors = { Main = Color3.fromRGB(28, 31, 36), Accent = Color3.fromRGB(171, 47, 39) },
        ShirtTemplate = 0,
        PantsTemplate = 0,
    },
}

-- Developer products are repeatable Robux purchases. Receipt handling is server-side.
GameConfig.Products = {
    CoinPouch = { DisplayName = "300 張車票幣", ProductId = 0, Coins = 300 },
    CoinCrate = { DisplayName = "1,000 張車票幣", ProductId = 0, Coins = 1000 },
}

return GameConfig
