local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
player.CameraMode = Enum.CameraMode.LockFirstPerson

local root = ReplicatedStorage:WaitForChild("LastTrain")
local remotes = root:WaitForChild("Remotes")
local objectiveEvent = remotes:WaitForChild("ObjectiveUpdate")
local shopRequest = remotes:WaitForChild("ShopRequest")
local GameConfig = require(root:WaitForChild("Shared"):WaitForChild("GameConfig"))

local gui = Instance.new("ScreenGui")
gui.Name = "LastTrainHUD"
gui.IgnoreGuiInset = true
gui.ResetOnSpawn = false
gui.DisplayOrder = 8
gui.Parent = player:WaitForChild("PlayerGui")

local function rounded(instance, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius or 10)
    corner.Parent = instance
end

local function stroke(instance, color, transparency)
    local line = Instance.new("UIStroke")
    line.Color = color
    line.Transparency = transparency or 0.3
    line.Thickness = 1
    line.Parent = instance
end

local objectiveCard = Instance.new("Frame")
objectiveCard.Size = UDim2.fromOffset(375, 104)
objectiveCard.Position = UDim2.new(0, 24, 0, 24)
objectiveCard.BackgroundColor3 = Color3.fromRGB(12, 18, 24)
objectiveCard.BackgroundTransparency = 0.18
objectiveCard.Parent = gui
rounded(objectiveCard, 12)
stroke(objectiveCard, Color3.fromRGB(89, 152, 166), 0.35)
local eyebrow = Instance.new("TextLabel")
eyebrow.BackgroundTransparency = 1
eyebrow.Position = UDim2.fromOffset(17, 11)
eyebrow.Size = UDim2.new(1, -34, 0, 22)
eyebrow.Font = Enum.Font.GothamBold
eyebrow.Text = "末班車  /  夜間維修任務"
eyebrow.TextColor3 = Color3.fromRGB(107, 201, 211)
eyebrow.TextSize = 13
eyebrow.TextXAlignment = Enum.TextXAlignment.Left
eyebrow.Parent = objectiveCard
local objectiveLabel = Instance.new("TextLabel")
objectiveLabel.BackgroundTransparency = 1
objectiveLabel.Position = UDim2.fromOffset(17, 39)
objectiveLabel.Size = UDim2.new(1, -34, 0, 51)
objectiveLabel.Font = Enum.Font.GothamMedium
objectiveLabel.Text = "等待站內廣播…"
objectiveLabel.TextColor3 = Color3.fromRGB(235, 239, 241)
objectiveLabel.TextSize = 17
objectiveLabel.TextWrapped = true
objectiveLabel.TextXAlignment = Enum.TextXAlignment.Left
objectiveLabel.TextYAlignment = Enum.TextYAlignment.Top
objectiveLabel.Parent = objectiveCard

local shopButton = Instance.new("TextButton")
shopButton.Size = UDim2.fromOffset(150, 44)
shopButton.Position = UDim2.new(1, -174, 0, 24)
shopButton.BackgroundColor3 = Color3.fromRGB(22, 36, 43)
shopButton.Text = "角色與補給  [M]"
shopButton.TextColor3 = Color3.fromRGB(224, 239, 239)
shopButton.TextSize = 14
shopButton.Font = Enum.Font.GothamBold
shopButton.Parent = gui
rounded(shopButton, 10)
stroke(shopButton, Color3.fromRGB(91, 171, 181), 0.25)

local crosshair = Instance.new("Frame")
crosshair.Size = UDim2.fromOffset(5, 5)
crosshair.AnchorPoint = Vector2.new(0.5, 0.5)
crosshair.Position = UDim2.fromScale(0.5, 0.5)
crosshair.BackgroundColor3 = Color3.fromRGB(223, 232, 229)
crosshair.BackgroundTransparency = 0.15
crosshair.Parent = gui
rounded(crosshair, 5)

local shop = Instance.new("Frame")
shop.Size = UDim2.new(0.84, 0, 0.8, 0)
shop.Position = UDim2.fromScale(0.5, 0.5)
shop.AnchorPoint = Vector2.new(0.5, 0.5)
shop.BackgroundColor3 = Color3.fromRGB(10, 15, 20)
shop.BackgroundTransparency = 0.04
shop.Visible = false
shop.Parent = gui
rounded(shop, 16)
stroke(shop, Color3.fromRGB(78, 146, 159), 0.2)
local sizeLimit = Instance.new("UISizeConstraint")
sizeLimit.MinSize = Vector2.new(310, 310)
sizeLimit.MaxSize = Vector2.new(850, 590)
sizeLimit.Parent = shop

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Position = UDim2.fromOffset(25, 18)
title.Size = UDim2.new(1, -100, 0, 34)
title.Font = Enum.Font.GothamBold
title.Text = "夜班更衣室"
title.TextColor3 = Color3.fromRGB(238, 241, 239)
title.TextSize = 22
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = shop
local balance = Instance.new("TextLabel")
balance.BackgroundTransparency = 1
balance.Position = UDim2.new(0, 25, 0, 56)
balance.Size = UDim2.new(1, -50, 0, 25)
balance.Font = Enum.Font.GothamMedium
balance.Text = "車票幣：…"
balance.TextColor3 = Color3.fromRGB(224, 183, 93)
balance.TextSize = 15
balance.TextXAlignment = Enum.TextXAlignment.Left
balance.Parent = shop
local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.fromOffset(40, 36)
closeButton.Position = UDim2.new(1, -58, 0, 18)
closeButton.BackgroundColor3 = Color3.fromRGB(34, 43, 48)
closeButton.Text = "×"
closeButton.TextColor3 = Color3.fromRGB(232, 236, 235)
closeButton.TextSize = 24
closeButton.Font = Enum.Font.Gotham
closeButton.Parent = shop
rounded(closeButton, 8)

local cards = Instance.new("Frame")
cards.BackgroundTransparency = 1
cards.Position = UDim2.fromOffset(24, 94)
cards.Size = UDim2.new(1, -48, 1, -163)
cards.Parent = shop
local grid = Instance.new("UIGridLayout")
grid.CellSize = UDim2.new(0.48, -7, 0, 112)
grid.CellPadding = UDim2.fromOffset(12, 12)
grid.SortOrder = Enum.SortOrder.LayoutOrder
grid.Parent = cards
local cardButtons = {}

local function makeSkinCard(key, info, order)
    local card = Instance.new("Frame")
    card.LayoutOrder = order
    card.BackgroundColor3 = Color3.fromRGB(22, 29, 34)
    card.Parent = cards
    rounded(card, 10)
    stroke(card, info.Colors.Accent, 0.72)
    local colorMark = Instance.new("Frame")
    colorMark.Size = UDim2.new(0, 7, 1, -18)
    colorMark.Position = UDim2.fromOffset(9, 9)
    colorMark.BackgroundColor3 = info.Colors.Main
    colorMark.Parent = card
    rounded(colorMark, 4)
    local name = Instance.new("TextLabel")
    name.BackgroundTransparency = 1
    name.Position = UDim2.fromOffset(27, 12)
    name.Size = UDim2.new(1, -40, 0, 25)
    name.Font = Enum.Font.GothamBold
    name.Text = info.DisplayName
    name.TextColor3 = Color3.fromRGB(232, 237, 236)
    name.TextSize = 16
    name.TextXAlignment = Enum.TextXAlignment.Left
    name.Parent = card
    local detail = Instance.new("TextLabel")
    detail.Name = "Detail"
    detail.BackgroundTransparency = 1
    detail.Position = UDim2.fromOffset(27, 40)
    detail.Size = UDim2.new(1, -40, 0, 19)
    detail.Font = Enum.Font.Gotham
    detail.Text = info.RequiresGamePass and (info.GamePassId > 0 and "Robux 永久解鎖" or "尚未開放") or (info.PriceCoins == 0 and "免費服裝" or (tostring(info.PriceCoins) .. " 車票幣"))
    detail.TextColor3 = Color3.fromRGB(155, 168, 171)
    detail.TextSize = 12
    detail.TextXAlignment = Enum.TextXAlignment.Left
    detail.Parent = card
    local button = Instance.new("TextButton")
    button.Name = "Action"
    button.Size = UDim2.new(1, -36, 0, 32)
    button.Position = UDim2.new(0, 27, 1, -42)
    button.BackgroundColor3 = Color3.fromRGB(43, 91, 98)
    button.TextColor3 = Color3.fromRGB(245, 247, 245)
    button.TextSize = 13
    button.Font = Enum.Font.GothamBold
    button.Parent = card
    rounded(button, 7)
    cardButtons[key] = { Button = button, Info = info }
end

local index = 0
for key, info in pairs(GameConfig.Skins) do
    index += 1
    makeSkinCard(key, info, index)
end

local productRow = Instance.new("Frame")
productRow.BackgroundTransparency = 1
productRow.Position = UDim2.new(0, 24, 1, -57)
productRow.Size = UDim2.new(1, -48, 0, 38)
productRow.Parent = shop
local productButtons = {}
local productIndex = 0
for key, product in pairs(GameConfig.Products) do
    productIndex += 1
    local button = Instance.new("TextButton")
    button.Name = key
    button.Size = UDim2.new(0.5, -6, 1, 0)
    button.Position = UDim2.new((productIndex - 1) * 0.5, (productIndex - 1) * 12, 0, 0)
    button.BackgroundColor3 = Color3.fromRGB(57, 57, 43)
    button.Text = product.DisplayName .. "  /  Robux"
    button.TextColor3 = Color3.fromRGB(241, 222, 166)
    button.TextSize = 12
    button.Font = Enum.Font.GothamBold
    button.Parent = productRow
    rounded(button, 8)
    productButtons[key] = button
end

local toast = Instance.new("TextLabel")
toast.Size = UDim2.new(0, 430, 0, 40)
toast.Position = UDim2.new(0.5, 0, 1, -82)
toast.AnchorPoint = Vector2.new(0.5, 0.5)
toast.BackgroundColor3 = Color3.fromRGB(12, 18, 22)
toast.BackgroundTransparency = 0.12
toast.Text = ""
toast.TextColor3 = Color3.fromRGB(236, 239, 234)
toast.TextSize = 14
toast.Font = Enum.Font.GothamMedium
toast.Visible = false
toast.Parent = gui
rounded(toast, 9)

local function showToast(message)
    toast.Text = tostring(message or "")
    toast.Visible = true
    task.delay(2.5, function() toast.Visible = false end)
end

local currentState
local function refreshShop()
    local ok, response = pcall(function()
        return shopRequest:InvokeServer("GetState")
    end)
    if not ok or not response or not response.state then return end
    currentState = response.state
    balance.Text = "車票幣：" .. tostring(currentState.Coins)
    for key, entry in pairs(cardButtons) do
        local owned = currentState.OwnedSkins[key] == true
        local equipped = currentState.EquippedSkin == key
        local button = entry.Button
        if equipped then
            button.Text = "使用中"
            button.BackgroundColor3 = Color3.fromRGB(49, 73, 69)
        elseif owned then
            button.Text = "穿上這套服裝"
            button.BackgroundColor3 = Color3.fromRGB(43, 91, 98)
        elseif entry.Info.RequiresGamePass then
            button.Text = entry.Info.GamePassId > 0 and "以 Robux 解鎖" or "尚未開放"
            button.BackgroundColor3 = entry.Info.GamePassId > 0 and Color3.fromRGB(103, 73, 36) or Color3.fromRGB(57, 62, 64)
        elseif entry.Info.PriceCoins > 0 then
            button.Text = "使用車票幣購買"
            button.BackgroundColor3 = Color3.fromRGB(43, 91, 98)
        else
            button.Text = "免費解鎖"
            button.BackgroundColor3 = Color3.fromRGB(43, 91, 98)
        end
    end
end

local function doRequest(action, key)
    local ok, response = pcall(function()
        return shopRequest:InvokeServer(action, key)
    end)
    if not ok or not response then
        showToast("連線忙碌，請稍後再試。")
        return
    end
    if response.promptType == "GamePass" and response.id > 0 then
        MarketplaceService:PromptGamePassPurchase(player, response.id)
    elseif response.promptType == "Product" and response.id > 0 then
        MarketplaceService:PromptProductPurchase(player, response.id)
    else
        showToast(response.message or "完成。")
        refreshShop()
    end
end

for key, entry in pairs(cardButtons) do
    entry.Button.Activated:Connect(function()
        if currentState and currentState.OwnedSkins[key] then
            doRequest("Equip", key)
        elseif entry.Info.RequiresGamePass then
            doRequest("PromptPass", key)
        else
            doRequest("BuyCoins", key)
        end
    end)
end
for key, button in pairs(productButtons) do
    button.Activated:Connect(function() doRequest("PromptProduct", key) end)
end

MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(purchaser, _passId, wasPurchased)
    if purchaser == player and wasPurchased then
        task.delay(1.5, refreshShop) -- UI refresh only; the server verifies and grants ownership.
    end
end)

local function setShopVisible(value)
    shop.Visible = value
    if value then refreshShop() end
end
shopButton.Activated:Connect(function() setShopVisible(not shop.Visible) end)
closeButton.Activated:Connect(function() setShopVisible(false) end)
UserInputService.InputBegan:Connect(function(input, processed)
    if processed then return end
    if input.KeyCode == Enum.KeyCode.M then setShopVisible(not shop.Visible) end
    if input.KeyCode == Enum.KeyCode.Escape and shop.Visible then setShopVisible(false) end
end)

objectiveEvent.OnClientEvent:Connect(function(stage, text, completed)
    if completed then
        objectiveLabel.Text = "列車開始移動了。\n你成功搭上末班車。"
        showToast("任務完成！獎勵車票幣已送達。")
    else
        objectiveLabel.Text = string.format("目標 %d / 3\n%s", math.clamp((tonumber(stage) or 0) + 1, 1, 3), tostring(text or "等待下一個指示"))
        if stage and stage > 0 then showToast("遠處傳來沉重的腳步聲…") end
    end
    if shop.Visible then refreshShop() end
end)

local function updateCoins()
    if shop.Visible then refreshShop() end
end
local leaderstats = player:WaitForChild("leaderstats", 20)
if leaderstats then
    local coins = leaderstats:WaitForChild("車票幣", 10)
    if coins then coins.Changed:Connect(updateCoins) end
end
